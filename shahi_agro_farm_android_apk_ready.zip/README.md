# SHAHI AGRO FARM — Android app starter

This is an Expo / React Native starter project. It is not an APK yet.

## Build an installable Android APK using a cloud build

You can do the setup from a phone using a browser-based cloud terminal such as GitHub Codespaces (availability/usage limits depend on your GitHub account).

1. Upload the files in this ZIP to a GitHub repository.
2. Open the repository on GitHub in your browser. Choose **Code → Codespaces → Create codespace on main** (if Codespaces is available to your account).
3. In the terminal, run:

   ```bash
   npm install
   npm install -g eas-cli
   eas login
   eas build:configure
   eas build --platform android --profile preview
   ```

4. Follow the Expo prompts. When the cloud build completes, open its build page and download the `.apk` file to your Android phone.
5. Open the downloaded APK and follow Android's installation prompts. Only install APKs you trust.

The build configuration in `eas.json` requests an APK rather than a Play Store AAB.

## Important limitations

- EAS Build compiles the app, but it does not add a backend, save orders online, or verify bKash/Nagad transactions.
- The current app is a prototype. Do not use it to accept real payments until server-side payment verification, order storage, privacy, and security have been implemented and tested.
